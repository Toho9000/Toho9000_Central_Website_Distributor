<style type="text/css">
<!--
.style4 {	color: #053983;
	font-size: 14px;
	font-weight: bold;
}
.style6 {color: #053983; font-size: 14px; }
-->
</style>
<p>All links from this page guarantee you the world's best sign-up bonus, which we've negotiated thanks to our status as the <br />
  largest online guide. This is what you get when you sign up through us...</p>
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="124" align="left" class="buttonTabs"><div align="center"><a href="#">Special Bonus</a></div></td>
    <td width="124" class="buttonTabs"><div align="center"><a href="#">Special Cash Freerolls</a></div></td>
    <td width="125" class="buttonTabs"><div align="center"><a href="#">Special Events</a></div></td>
    <td width="356" class="underline">&nbsp;</td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td width="16%" class="dottedUnderline"><img src="<?=TEMPLATEDIR;?>images/bonuses_AbsolutePoker.gif" width="113" height="30" /></td>
    <td width="43%" valign="top" class="dottedUnderline"><table width="81%" border="0" cellpadding="5" cellspacing="0" class="bonusBox">
      <tr>
        <td><p>World-best $600 sign-up bonus at Absolute Poker</p>
              <ul>
                <li> $600 at 150% deposit match<br />
                </li>
                <li>Use bonus code: PLISTAP<br />
                </li>
                <li>Expiration time: 60 Days<br />
                </li>
                <li>Minimum deposit: $50</li>
              </ul></td>
      </tr>
    </table></td>
    <td width="41%" valign="top" class="dottedUnderline"><p align="center"><img src="<?=TEMPLATEDIR;?>images/spadeDollarLogo.gif" width="37" height="39" align="left" /><span class="style6">$600 Sign-up Bonus</span></p>
        <p align="center" class="style4">Visit Absolute Poker</p>
      <p align="center" class="bonusBox">Bonus Code: PLISTAP</p>
      <p align="center" class="style6">Direct Download | See Full Review</p></td>
  </tr>
  <tr>
    <td class="dottedUnderline"><img src="<?=TEMPLATEDIR;?>images/bonuses_Bwin.gif" width="112" height="30" /></td>
    <td class="dottedUnderline"><table width="81%" border="0" cellpadding="5" cellspacing="0" class="bonusBox">
      <tr>
        <td><p>World-best $600 sign-up bonus at Absolute Poker</p>
              <ul>
                <li> $600 at 150% deposit match<br />
                </li>
                <li>Use bonus code: PLISTAP<br />
                </li>
                <li>Expiration time: 60 Days<br />
                </li>
                <li>Minimum deposit: $50</li>
              </ul></td>
      </tr>
    </table></td>
    <td class="dottedUnderline"><p align="center"><img src="<?=TEMPLATEDIR;?>images/spadeDollarLogo.gif" width="37" height="39" align="left" /><span class="style6">$600 Sign-up Bonus</span></p>
        <p align="center" class="style4">Visit Absolute Poker</p>
      <p align="center" class="bonusBox">Bonus Code: PLISTAP</p>
      <p align="center" class="style6">Direct Download | See Full Review</p></td>
  </tr>
  <tr>
    <td class="dottedUnderline"><img src="<?=TEMPLATEDIR;?>images/bonuses_pokerStars.gif" width="112" height="30" /></td>
    <td class="dottedUnderline"><table width="81%" border="0" cellpadding="5" cellspacing="0" class="bonusBox">
      <tr>
        <td><p>World-best $600 sign-up bonus at Absolute Poker</p>
              <ul>
                <li> $600 at 150% deposit match<br />
                </li>
                <li>Use bonus code: PLISTAP<br />
                </li>
                <li>Expiration time: 60 Days<br />
                </li>
                <li>Minimum deposit: $50</li>
              </ul></td>
      </tr>
    </table></td>
    <td class="dottedUnderline"><p align="center"><img src="<?=TEMPLATEDIR;?>images/spadeDollarLogo.gif" width="37" height="39" align="left" /><span class="style6">$600 Sign-up Bonus</span></p>
        <p align="center" class="style4">Visit Absolute Poker</p>
      <p align="center" class="bonusBox">Bonus Code: PLISTAP</p>
      <p align="center" class="style6">Direct Download | See Full Review</p></td>
  </tr>
  <tr>
    <td class="dottedUnderline"><img src="<?=TEMPLATEDIR;?>images/bonuses_hollywood.gif" width="114" height="30" /></td>
    <td class="dottedUnderline"><table width="81%" border="0" cellpadding="5" cellspacing="0" class="bonusBox">
      <tr>
        <td><p>World-best $600 sign-up bonus at Absolute Poker</p>
              <ul>
                <li> $600 at 150% deposit match<br />
                </li>
                <li>Use bonus code: PLISTAP<br />
                </li>
                <li>Expiration time: 60 Days<br />
                </li>
                <li>Minimum deposit: $50</li>
              </ul></td>
      </tr>
    </table></td>
    <td class="dottedUnderline"><p align="center"><img src="<?=TEMPLATEDIR;?>images/spadeDollarLogo.gif" width="37" height="39" align="left" /><span class="style6">$600 Sign-up Bonus</span></p>
        <p align="center" class="style4">Visit Absolute Poker</p>
      <p align="center" class="bonusBox">Bonus Code: PLISTAP</p>
      <p align="center" class="style6">Direct Download | See Full Review</p></td>
  </tr>
  <tr>
    <td class="dottedUnderline"><img src="<?=TEMPLATEDIR;?>images/bonuses_UltimateBet.gif" width="113" height="30" /></td>
    <td class="dottedUnderline"><table width="81%" border="0" cellpadding="5" cellspacing="0" class="bonusBox">
      <tr>
        <td><p>World-best $600 sign-up bonus at Absolute Poker</p>
              <ul>
                <li> $600 at 150% deposit match<br />
                </li>
                <li>Use bonus code: PLISTAP<br />
                </li>
                <li>Expiration time: 60 Days<br />
                </li>
                <li>Minimum deposit: $50</li>
              </ul></td>
      </tr>
    </table></td>
    <td class="dottedUnderline"><p align="center"><img src="<?=TEMPLATEDIR;?>images/spadeDollarLogo.gif" width="37" height="39" align="left" /><span class="style6">$600 Sign-up Bonus</span></p>
        <p align="center" class="style4">Visit Absolute Poker</p>
      <p align="center" class="bonusBox">Bonus Code: PLISTAP</p>
      <p align="center" class="style6">Direct Download | See Full Review</p></td>
  </tr>
  <tr>
    <td class="dottedUnderline"><img src="<?=TEMPLATEDIR;?>images/bonuses_PKR.gif" width="112" height="31" /></td>
    <td class="dottedUnderline"><table width="81%" border="0" cellpadding="5" cellspacing="0" class="bonusBox">
      <tr>
        <td><p>World-best $600 sign-up bonus at Absolute Poker</p>
              <ul>
                <li> $600 at 150% deposit match<br />
                </li>
                <li>Use bonus code: PLISTAP<br />
                </li>
                <li>Expiration time: 60 Days<br />
                </li>
                <li>Minimum deposit: $50</li>
              </ul></td>
      </tr>
    </table></td>
    <td class="dottedUnderline"><p align="center"><img src="<?=TEMPLATEDIR;?>images/spadeDollarLogo.gif" width="37" height="39" align="left" /><span class="style6">$600 Sign-up Bonus</span></p>
        <p align="center" class="style4">Visit Absolute Poker</p>
      <p align="center" class="bonusBox">Bonus Code: PLISTAP</p>
      <p align="center" class="style6">Direct Download | See Full Review</p></td>
  </tr>
</table>
<p></p>
