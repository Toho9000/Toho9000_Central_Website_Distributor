<?
	print $news_data['content_text'];
?>