You successfully created the API token �whmapitoken�.

Copy the following token to a safe place: 8FZ5OAJ05NVTV2NG5JV67U6OBGM3B27H