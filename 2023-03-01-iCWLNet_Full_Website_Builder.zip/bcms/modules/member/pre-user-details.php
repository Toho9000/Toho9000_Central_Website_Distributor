<?php
	//print "--666---".var_export($_SESSION,true)."===";
	/*
	if(isset($_POST['Submit'])){
		if($_POST['Submit']){
			
			$membersID=$_SESSION['membersID'];
			$m= new UpdateDatabase($log);
			$m->Set_Log($log);
			$m->Set_Database($r);
			//$m->Set_Log_All();
			$m->AddPosts($_POST,$_FILES);
			$m->AddSkip(array("id"));
			$m->AddTable("users");
			$m->AddID($_SESSION['membersID']);
			$m->DoStuff();
		}
	}
	*/
?>