<table width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr>
    <td><iframe src="http://promotions.noodnet.com/ibanner.php?id=7" width="150" height="60" scrolling="no" frameborder="0"></iframe></td>
    <td><img src="images/brwbuy.gif" alt="Browse Buy Logo" width="400" height="69"></td>
    <td><iframe src="http://promotions.noodnet.com/ibanner.php?id=8" width="150" height="60" scrolling="no" frameborder="0"></iframe></td>
  </tr>
  <tr>
    <td colspan="2"><h1 align="center">&nbsp;</h1>
      <p><font size="2">To browse the Nood Network Database you can browse by <strong><font color="#0080C0">many different methods</font></strong>. The first and most obvious one is
        to <strong><font color="#0080C0">list everything</font></strong> that is available, and go
        through this list of items one by one. Alternatively, if you are interested in trading
        with someone in the same <font color="#0080C0"><strong>state</strong></font> or a similar <font color="#0080C0"><strong>postcode</strong></font>, you can search based on these criteria.
        Most commonly, if you are looking for a particular <strong><font color="#0080C0">product</font></strong>,
        you can also search for Nood items based on the product name - <a href="advancedsearchtips.htm">Advanced Searching Tips</a>. For the new users a <a href="screen_examples_purchase.html">Sample Purchase Screen</a> is available complete with
        the automatic email that is sent.</font></p>
      <div align="center">
        <center>
          <table border="0" width="400">
            <tr>
              <td width="400" bgcolor="#A0D3FA"><big><strong>Search by Entries Last 
                Stored / Updated</strong></big></td>
            </tr>
            <tr>
              <td width="400"><form method="POST" name="RecentForm" action="/members/browse-buy-results/">
                  <input type="hidden" name="VTI-GROUP3" value="0">
                  <input type="hidden" name="TimeFrame" value>
                  <table border="0" width="393">
                    <tr>
                      <td width="152"><font size="2">
                        <input type="radio" value="ASC" checked name="AscDesc">
                        Ascending<br>
                        <input type="radio" name="AscDesc" value="DESC">
                        Descending</font></td>
                      <td width="241"><div align="right">
                          <p><font size="2">
                            <input type="button" value="List Last 24 Hour Items" name="Day" onClick="SetLastDay()">
                          </font></p>
                      </div>
                          <div align="right">
                            <p><font size="2">
                              <input type="button" value=" List Last Week Items  " name="week" onClick="SetLastWeek()">
                            </font></p>
                          </div>
                        <div align="right">
                            <p><font size="2">
                              <input type="button" value=" List Last Month Items  " name="month" onClick="SetLastMonth()">
                            </font>                        </div></td>
                    </tr>
                  </table>
              </form></td>
            </tr>
          </table>
        </center>
      </div>
      <div align="center">
        <center>
          <table border="0" width="400">
            <tr>
              <td width="400" bgcolor="#A0D3FA"><big><strong>Search by Nood Product Criteria</strong></big></td>
            </tr>
            <tr>
              <td width="400"><form method="POST" name="search" action="/members/browse-buy-results/">
                  <input type="hidden" name="VTI-GROUP" value="0">
                <table border="0" width="393">
                    <tr>
                      <td width="291"><font size="2">Name :
                        <input type="text" name="name" size="24">
                        </font>
                          <p><font size="2">State :
                            <select name="state" size="1">
                                  <option selected value="All States">All States</option>
                                  <option value="Queensland">Queensland</option>
                                  <option value="New South Wales">New South Wales</option>
                                  <option value="Victoria">Victoria</option>
                                  <option value="South Australia">South Australia</option>
                                  <option value="Western Australia">Western Australia</option>
                                  <option value="Tasmania">Tasmania</option>
                                  <option value="Australian Capital Territory">Australian Capital Territory</option>
                                  <option value="Northern Territory">Northern Territory</option>
                                </select>
                          </font></p>
                        <p><font size="2">PostCode :
                          <input type="text" name="postcode" size="8">
                        </font></p>
                        <p><font size="2">Membership :
                          <select name="type" size="1">
                                  <option selected value="0">All Types</option>
                                  <option value="1">Retail Pharmacy</option>
                                  <option value="2">Pharmacy Buy Groups</option>
                                  <option value="3">Hospital Pharmacy</option>
                                  <option value="4">Central Stores - Hospital</option>
                                  <option value="5">Pharmacy Wholesaler</option>
                                  <option value="6">Manufacturer</option>
                                </select>
                        </font></td>
                      <td width="102"><div align="left">
                        <p><font size="2">
                          <input type="radio" value="ASC" checked name="AscDesc">
                          Ascending<br>
                            <input type="radio" name="AscDesc" value="DESC">
                          Descending</font></p>
                      </div>
                          <div align="center">
                        <center>
                        <p><font size="2">
                          <input type="submit" value="Search" name="B1">
                        </font></td>
                    </tr>
                  </table>
              </form></td>
            </tr>
            <tr align="center">
              <td>&nbsp;</td>
            </tr>
          </table>
        </center>
      </div>
      <font size="2">
      <p align="left">When buyers purchase items, the details of each seller are revealed, and
        an automatic e-mail is sent to each seller advising of a sale. It is the responsibility of
        buyers to make contact with sellers and forward payments to sellers - <strong><font color="#0080C0">same day if possible. </font></strong>If&nbsp;sellers are able to manually
        key credit card transactions in EFTPOS machines, it may provide a convenient payment
        option. The prices listed by sellers include postage. It is up to sellers to arrange and
        pay for <a href="australiapost.htm">postage</a> of the item.</p>
      </font> <font size="2">
      <p align="left">Likewise we ask that sellers forward purchased items to buyers promptly
        -<strong><font color="#0080C0"> same day if possible</font></strong>. &nbsp; A record of
        sales appears in the the seller's&nbsp; 'sold file' and is used to determine the Nood
        Network selling fee. </p>
    </font></td>
    <td valign="top"><iframe src="http://promotions.noodnet.com/ibanner.php?id=9" width="150" height="300" scrolling="no" frameborder="0"></iframe>
    <br>
    <iframe src="http://promotions.noodnet.com/ibanner.php?id=10" width="150" height="300" scrolling="no" frameborder="0"></iframe></td>
  </tr>
  <tr>
    <td colspan="3" align="center"><iframe src="http://promotions.noodnet.com/ibanner.php?id=11" width="450" height="100" scrolling="no" frameborder="0"></iframe></td>
  </tr>
</table>