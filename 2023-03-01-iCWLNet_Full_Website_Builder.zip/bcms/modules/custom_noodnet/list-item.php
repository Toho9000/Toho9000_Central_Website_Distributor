<table width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr>
    <td width="16%"><iframe src="http://promotions.noodnet.com/ibanner.php?id=7" width="150" height="60" scrolling="no" frameborder="0"></iframe></td>
    <td width="68%"><h1 align="center" style="border: 1 solid #0080C0">&nbsp;</h1></td>
    <td width="16%" align="right"><iframe src="http://promotions.noodnet.com/ibanner.php?id=8" width="150" height="60" scrolling="no" frameborder="0"></iframe></td>
  </tr>
  <tr>
    <td colspan="2" valign="top"><p align="center">&nbsp;</p>
      <p><font size="2"><br>
        To list items on the Network&nbsp; simply fill out the table below. If you need help with
        listing have a look at our&nbsp; <a href="noodlistingtips.htm">listing tips</a>. All items
        should be listed on the Network excluding GST. Before you list any new items, you should
        consider the <a href="http://noodnet.com/cgi-bin/member-sell-details.pl">current items
          that you have listed</a> &amp;&nbsp; the <a href="fees.html">Nood Fee structure</a>.&nbsp;<br>
        Remember, the lower the price - the quicker the sale!</font></p>
      <form name="member_sell" method="POST" action="http://noodnet.com/cgi-bin/member-sell.pl" enctype="multipart/form-data">
        <input type="hidden" name="VTI-GROUP" value="0">
        <table border="0" width="572"
  cellspacing="1">
          <tr>
            <td width="329" align="right"><font size="2">Name of Item :</font></td>
            <td width="377"><input type="text" name="name" size="20"></td>
          </tr>
          <tr>
            <td width="329" align="right"><font size="2">Strength :</font></td>
            <td width="377"><input type="text" name="strength" size="20"></td>
          </tr>
          <tr>
            <td width="329" align="right"><font size="2">Packet Size :</font></td>
            <td width="377"><input type="text" name="size" size="6"></td>
          </tr>
          <tr>
            <td width="329" align="right"><font size="2">Quantity :</font></td>
            <td width="377"><input type="text" name="quantity" size="6"></td>
          </tr>
          <tr>
            <td width="329" align="right"><font size="2">Expiry Date (Month) :</font></td>
            <td width="377"><select name="month" size="1">
                <option selected value="01">Jan</option>
                <option value="02">Feb</option>
                <option value="03">Mar</option>
                <option value="04">Apr</option>
                <option value="05">May</option>
                <option value="06">Jun</option>
                <option value="07">Jul</option>
                <option value="08">Aug</option>
                <option value="09">Sep</option>
                <option value="10">Oct</option>
                <option value="11">Nov</option>
                <option value="12">Dec</option>
            </select></td>
          </tr>
          <tr>
            <td width="329" align="right"><font size="2">Expiry Date (Year) :</font></td>
            <td width="377"><select name="year" size="1">
                <option value="2007">2007</option>
                <option value="2008">2008</option>
                <option value="2009">2009</option>
                <option value="2010">2010</option>
                <option value="2011">2011</option>
                <option value="2012">2012</option>
                <option value="2013">2013</option>
                <option value="2014">2014</option>
                <option value="2015">2015</option>
                <option value="2016">2016</option>
                <option value="2017">2017</option>
                <option value="2018">2018</option>
                <option value="2019">2019</option>
                <option value="2020">2020</option>
            </select></td>
          </tr>
          <tr>
            <td width="329" align="right"><font size="2">Price (per pack_size) $:</font></td>
            <td width="377"><input type="text" name="price" size="11"></td>
          </tr>
          <tr>
            <td width="329" align="right"><font size="2">Comments :</font></td>
            <td width="377"><textarea rows="4" name="comments" cols="37"></textarea></td>
          </tr>
          <tr>
            <td width="329" align="right"><font size="2">Picture :</font></td>
            <td width="377"><input name="picture" type="file" id="picture"></td>
          </tr>
        </table>
        <p>
          <input type="button" value="Add Item" name="Add_Item" onClick="CheckEverything()">
          <input
  type="reset" value="Reset" name="B2">
        </p>
      </form>
      <p><font size="2">At Nood Network it is seller's responsibility to arrange and pay for <a
href="australiapost.htm">postage</a> of the item.&nbsp;<br>
        Once you list&nbsp; your items they are <strong><font color="#0080C0">immediately
          available</font></strong> for purchase by other members of&nbsp; the Network.<br>
        When they buy your item/s you will receive an e-mail advising of the sale and the buyers
        details. It is then up to buyer and seller to make contact and arrange for both freight
        and payment of the item - <strong><font color="#0080C0">what could be simpler!</font></strong></font></p>
      <p></p>      <p>&nbsp;</p>
    </td>
    <td align="right" valign="top"><iframe src="http://promotions.noodnet.com/ibanner.php?id=9" width="150" height="300" scrolling="no" frameborder="0"></iframe>
        <br>
        <iframe src="http://promotions.noodnet.com/ibanner.php?id=10" width="150" height="300" scrolling="no" frameborder="0"></iframe></td>
  </tr>
  <tr>
    <td colspan="3" align="center"><iframe src="http://promotions.noodnet.com/ibanner.php?id=11" width="450" height="100" scrolling="no" frameborder="0"></iframe></td>
  </tr>
</table>
