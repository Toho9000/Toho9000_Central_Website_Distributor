<?php
	print $message;
?>
<br><br>
{{message}}