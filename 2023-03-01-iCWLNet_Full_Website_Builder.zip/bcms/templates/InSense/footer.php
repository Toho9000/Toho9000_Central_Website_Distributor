</div>
<!-- Content END -->
 
<div class="Footer"><div class="FooterCorner"></div>
<?php include ($template_data['TEMPLATEPATH'] . "/403.php"); ?>
<p><strong>Copyright &copy; 2007 - <? bloginfo('name'); ?> - is proudly powered by <a href="http://www.wordpress.com/">WordPress</a></strong><br />
InSense 1.0 Theme by <a href="http://www.designdisease.com/">Design Disease</a> brought to you by <a href="http://www.hostgator.com/" title="HostGator Web Hosting">HostGator Web Hosting.</a></p>
<?php wp_footer(); ?>
</div>

</div></div>
<!-- bgcontain & bgcontainIn END -->

</body>
</html>
