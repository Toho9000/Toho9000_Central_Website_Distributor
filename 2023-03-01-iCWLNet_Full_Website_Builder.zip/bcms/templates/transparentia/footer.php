<div class="footer">

	<div class="left">
		&copy; <?=date("Y");?> <a href="<?php bloginfo('url');?>"><?php bloginfo('name');?></a>
	</div>
	
	<div class="right"><a href="http://creativeweblogic.net">Website Design Development Hosting Promotion Programming</a> by <a href="http://smoothbuild.website/">Website Builder</a></div>

	<div class="clearer">&nbsp;</div>

</div>