<?php get_header(); ?>

	<div id="content">

		<?php fourOhFour(); ?>

	</div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>